<p align="center">
<p>👋 A simple currency conversion application linked to an API that trackk the latest changes.</p>

  <img align="center" src="https://github.com/zumrudu-anka/react-currency-converter/blob/gh-pages/presentation/CurrencyConverter.gif" />
</p>
